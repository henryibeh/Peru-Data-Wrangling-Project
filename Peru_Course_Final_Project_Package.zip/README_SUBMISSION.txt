PART 1: Submit Peru_Data_Wrangling_Notebook.html (executed notebook with comments).
PART 2: Create your own GitHub repository and upload Peru_Primary_Enrollment_GDP_2001_2020.csv, Peru_Primary_Enrollment_GDP_2001_2020.db, Peru_Data_Description.json. Take genuine screenshots of each file in the browser; screenshots cannot be produced until you upload them.
PART 3: Complete placeholders in Peru_Final_Project_Report_DRAFT.docx, insert your real GitHub screenshots and HTML notebook pages into the appendix, then export as PDF or DOCX as instructed.
Note: Raw input ZIP files are not packaged; keep them with the .ipynb if re-running locally.
